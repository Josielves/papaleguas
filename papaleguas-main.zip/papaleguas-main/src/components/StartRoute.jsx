import { useEffect, useState } from 'react'
import {
  getRouteWithStops,
  startRoute,
  completeRoute,
  buildGoogleMapsUrl,
  buildAppleMapsUrl,
  buildWazeUrl,
  getRegionName,
} from '../lib/supabase'

// Tela do motorista para iniciar a rota: mostra as paradas já
// ordenadas por proximidade (sem precisar pesquisar cada endereço)
// e oferece atalhos para abrir a rota completa no app de GPS
// preferido do motorista.
export default function StartRoute({ routeId, onClose }) {
  const [route, setRoute] = useState(null)
  const [loading, setLoading] = useState(true)
  const [starting, setStarting] = useState(false)

  useEffect(() => {
    load()
  }, [routeId])

  async function load() {
    setLoading(true)
    const { data } = await getRouteWithStops(routeId)
    setRoute(data)
    setLoading(false)
  }

  async function handleStart() {
    setStarting(true)
    await startRoute(routeId)
    await load()
    setStarting(false)
  }

  async function handleComplete() {
    await completeRoute(routeId)
    onClose?.()
  }

  if (loading) return <div className="skeleton" style={{ height: '14rem', borderRadius: 'var(--radius-lg)' }} />
  if (!route) return <div className="empty-state">Rota não encontrada.</div>

  const stops = route.orderedStops || []
  const missingLocation = route.bookingsWithoutLocation || []

  const gmapsUrl = buildGoogleMapsUrl({
    originLat: route.origin_lat,
    originLng: route.origin_lng,
    stops,
    destLat: route.destination_lat,
    destLng: route.destination_lng,
  })
  const appleUrl = buildAppleMapsUrl({
    originLat: route.origin_lat,
    originLng: route.origin_lng,
    stops,
    destLat: route.destination_lat,
    destLng: route.destination_lng,
  })

  const isActive = route.status === 'in_progress'
  const isDone = route.status === 'completed'

  return (
    <div style={{ maxWidth: '38rem' }}>
      <div className="section-heading">
        <h2>{getRegionName(route.origin_region)} → {getRegionName(route.destination_region)}</h2>
        <span className={`status-pill status-pill--${isDone ? 'confirmed' : isActive ? 'confirmed' : 'pending'}`}>
          {isDone ? 'Concluída' : isActive ? 'Em andamento' : 'Pronta para iniciar'}
        </span>
      </div>

      <div className="surface-raised" style={{ borderRadius: 'var(--radius-lg)', padding: '1.25rem', marginBottom: '1.25rem' }}>
        <h3 style={{ marginBottom: '0.75rem' }}>Paradas em ordem de coleta</h3>

        {stops.length === 0 ? (
          <p>Nenhum passageiro com ponto de embarque cadastrado ainda.</p>
        ) : (
          <ol style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', margin: 0, padding: 0, listStyle: 'none' }}>
            {stops.map((s, i) => (
              <li key={s.id} style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
                <span className="stepper__badge" style={{ flexShrink: 0 }}>{i + 1}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ color: 'var(--cream-100)', fontWeight: 600, margin: 0 }}>
                    {s.passenger?.name ?? 'Passageiro'}
                  </p>
                  <p style={{ fontSize: '0.8125rem', margin: '0.125rem 0' }}>{s.pickup_address}</p>
                  <span className="text-mono" style={{ fontSize: '0.75rem', color: 'var(--mist-400)' }}>
                    ~{s.distanceFromPrevKm} km do ponto anterior · assento {s.seat_number}
                  </span>
                </div>
                <a
                  href={buildWazeUrl({ lat: s.pickup_lat, lng: s.pickup_lng })}
                  target="_blank"
                  rel="noreferrer"
                  className="btn btn-secondary btn-icon"
                  title="Navegar até esta parada no Waze"
                >
                  📍
                </a>
              </li>
            ))}
          </ol>
        )}

        {missingLocation.length > 0 && (
          <div className="form-error" style={{ marginTop: '0.875rem' }}>
            {missingLocation.length === 1
              ? '1 passageiro não informou ponto de embarque com localização — combine o local por chat.'
              : `${missingLocation.length} passageiros não informaram ponto de embarque com localização — combine o local por chat.`}
          </div>
        )}

        <div className="route-divider" style={{ margin: '1rem 0' }} />
        <p style={{ fontSize: '0.8125rem' }}>
          Destino final: <strong style={{ color: 'var(--cream-100)' }}>{route.destination_address}</strong>
        </p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.625rem' }}>
        {!isActive && !isDone && (
          <button className="btn btn-primary btn-block" onClick={handleStart} disabled={starting}>
            {starting ? 'Iniciando...' : '🚦 Iniciar rota e avisar passageiros'}
          </button>
        )}

        <div style={{ display: 'flex', gap: '0.625rem', flexWrap: 'wrap' }}>
          <a href={gmapsUrl} target="_blank" rel="noreferrer" className="btn btn-secondary" style={{ flex: 1 }}>
            Abrir no Google Maps
          </a>
          <a href={appleUrl} target="_blank" rel="noreferrer" className="btn btn-secondary" style={{ flex: 1 }}>
            Abrir no Apple Maps
          </a>
        </div>
        <p style={{ fontSize: '0.75rem', color: 'var(--mist-600)' }}>
          O Waze só navega até um ponto por vez — use o ícone 📍 ao lado de cada parada para ir até ela.
        </p>

        {isActive && (
          <button className="btn btn-danger btn-block" onClick={handleComplete}>
            Concluir rota
          </button>
        )}
      </div>
    </div>
  )
}
