import { useEffect, useRef, useState } from 'react'
import { supabase } from '../lib/supabase'

const ICONS = {
  new_booking: '💺',
  booking_cancelled: '⚠️',
}

// Sino de notificações do motorista. Só depende do export `supabase`
// que já existe em lib/supabase.js — não usa nenhuma função nova,
// então não conflita com orderStops / whatsAppLink / startRoute.
export default function NotificationBell({ userId }) {
  const [open, setOpen] = useState(false)
  const [notifications, setNotifications] = useState([])
  const [unreadCount, setUnreadCount] = useState(0)
  const panelRef = useRef(null)

  useEffect(() => {
    if (!userId) return
    let active = true

    ;(async () => {
      const { data } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(50)
      if (active && data) setNotifications(data)

      const { count } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .eq('read', false)
      if (active) setUnreadCount(count ?? 0)
    })()

    const channel = supabase
      .channel(`notifications:${userId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'notifications',
        filter: `user_id=eq.${userId}`,
      }, payload => {
        setNotifications(prev => [payload.new, ...prev])
        setUnreadCount(prev => prev + 1)
      })
      .subscribe()

    return () => {
      active = false
      try { channel.unsubscribe() } catch { /* já pode ter sido removido */ }
    }
  }, [userId])

  useEffect(() => {
    function handleClickOutside(e) {
      if (panelRef.current && !panelRef.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  async function handleToggle() {
    const willOpen = !open
    setOpen(willOpen)
    if (willOpen && unreadCount > 0) {
      await supabase.from('notifications').update({ read: true }).eq('user_id', userId).eq('read', false)
      setUnreadCount(0)
      setNotifications(prev => prev.map(n => ({ ...n, read: true })))
    }
  }

  async function handleMarkOne(id) {
    await supabase.from('notifications').update({ read: true }).eq('id', id)
    setNotifications(prev => prev.map(n => (n.id === id ? { ...n, read: true } : n)))
  }

  function timeAgo(dateStr) {
    const diffMs = Date.now() - new Date(dateStr).getTime()
    const mins = Math.floor(diffMs / 60000)
    if (mins < 1) return 'agora'
    if (mins < 60) return `${mins}min`
    const hours = Math.floor(mins / 60)
    if (hours < 24) return `${hours}h`
    return `${Math.floor(hours / 24)}d`
  }

  return (
    <div style={{ position: 'relative' }} ref={panelRef}>
      <button className="btn btn-ghost btn-icon" style={{ position: 'relative' }} onClick={handleToggle} aria-label="Notificações">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
          <path d="M13.73 21a2 2 0 0 1-3.46 0" />
        </svg>
        {unreadCount > 0 && (
          <span className="unread-badge" style={{ position: 'absolute', top: 2, right: 2 }}>
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div
          className="surface-raised"
          style={{
            position: 'absolute',
            right: 0,
            top: '2.75rem',
            width: '22rem',
            maxWidth: '90vw',
            maxHeight: '28rem',
            overflowY: 'auto',
            borderRadius: 'var(--radius-lg)',
            boxShadow: 'var(--shadow-elev)',
            zIndex: 50,
          }}
        >
          <div className="modal-panel__header">
            <h3>Notificações</h3>
          </div>

          {notifications.length === 0 ? (
            <div className="empty-state">Nenhuma notificação ainda.</div>
          ) : (
            <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
              {notifications.map(n => (
                <li
                  key={n.id}
                  onClick={() => handleMarkOne(n.id)}
                  style={{
                    padding: '0.875rem 1.125rem',
                    borderBottom: '1px solid var(--line-700)',
                    display: 'flex',
                    gap: '0.75rem',
                    cursor: 'pointer',
                    background: n.read ? 'transparent' : 'var(--amber-950)',
                  }}
                >
                  <span style={{ fontSize: '1.25rem', flexShrink: 0 }}>{ICONS[n.type] ?? '🔔'}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ color: 'var(--cream-100)', fontWeight: 600, fontSize: '0.875rem', margin: 0 }}>
                      {n.title}
                    </p>
                    <p style={{ fontSize: '0.8125rem', margin: '0.125rem 0 0' }}>{n.body}</p>
                    <span className="text-mono" style={{ fontSize: '0.6875rem', color: 'var(--mist-600)' }}>
                      {timeAgo(n.created_at)}
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  )
}
